
export interface User {
    name: string;
    phone: string;
    zipCode: string;
    adress: string;
    neighborhood: string;
    complement: string;
    user: string;
}
