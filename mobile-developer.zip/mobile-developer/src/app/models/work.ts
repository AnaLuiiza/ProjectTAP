
export interface Work {
    payload: {
        _document: {
            proto: {
                fields: {
                    description: {
                        id: string;
                        idBeacon: string;
                        work: string;
                        author: string;
                        date: string;
                        link: string;
                        description: string;
                    }
                }
            }

        }

    }



}